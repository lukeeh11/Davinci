$(function(e) {

    "use strict";
      
      /*===========================================================================
      *
      *  CONFIGURATION DROPDOWN MENUS 
      *
      *============================================================================*/
      $(document).ready(function(){

          $('#support-category').awselect(); 

          $('#support-priority').awselect(); 

          $('#notification-type').awselect(); 

          $('#notification-action').awselect();

          $('#response-status').awselect();

          $('#user-country').awselect();

          $('#user-status').awselect();

          $('#user-group').awselect();

          $('#smtp-encryption').awselect();

          $('#registration').awselect();

          $('#email-verification').awselect();

          $('#user-role').awselect();

          $('#login-oauth').awselect();

          $('#date-format').awselect();

          $('#time-zone').awselect();

          $('#support-ticket').awselect();

          $('#project').awselect();

          $('#faq-status').awselect();

          $('#user-notification').awselect();

          $('#user-support').awselect();

          $('#2fa-status').awselect();

          $('#plan-status').awselect();

          $('#currency').awselect();

          $('#featured').awselect();

          $('#free-plan').awselect();

          $('#paypal-url').awselect();

          $('#braintree').awselect();

          $('#invoice-currency').awselect();

          $('#invoice-language').awselect();

          $('#invoice-country').awselect();

          $('#payment-option').awselect();

          $('#template-selection').awselect();

          $('#language').awselect();

          $('#creativity').awselect();

          $('#tone').awselect();

          $('#default-model-user').awselect();

          $('#default-model-admin').awselect();

          $('#templates-admin').awselect();

          $('#templates-user').awselect();
          
          $('#image-feature-user').awselect();

          $('#image-feature').awselect();

          $('#templates').awselect();

          $('#frequency').awselect();

          $('#max-results').awselect();

          $('#del-project').awselect();

          $('#set-project').awselect();

          $('#resolution').awselect();

      }); 
  
  });
  
  
  